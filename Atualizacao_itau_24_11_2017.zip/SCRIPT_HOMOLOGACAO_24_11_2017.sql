----------------------------------------------------------------------------
-- CRIA��O DE REGISTROS NO GAP060 DEFINI��ES PARAMETROS DIVERSOS NO SISTEMA
----------------------------------------------------------------------------
USE [SICOF]
GO

INSERT INTO GAP060 (empresa, aplicacao, tipo_param, cod_param, descricao, perc_abat, deb_cred, cod_integ) VALUES('   ','CTB','df','IP                  ','ID POLITICA ITAU     2 40 N NASNN       ',0.00,' ','')
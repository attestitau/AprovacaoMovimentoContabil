-- SCRIPT para configura��o de param_prog da rotinas
UPDATE gap020 set param_prog = 'SS                  ' WHERE deleted = 0 AND aplicacao = 'CTB' and modulo = 'CO' AND ROTINA  = 'LI' AND programa = 'CTB540'
UPDATE gap020 set param_prog = 'F   USSS            ' WHERE deleted = 0 AND aplicacao = 'CTB' and modulo = 'ED' AND ROTINA  = 'IT' AND programa = 'CTB317'
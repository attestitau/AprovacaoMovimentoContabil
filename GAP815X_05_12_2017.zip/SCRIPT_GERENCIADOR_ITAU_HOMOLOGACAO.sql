
USE SICOF
INSERT INTO GAP060 (empresa, aplicacao, tipo_param, cod_param, descricao, perc_abat, deb_cred, geral, cod_integ) VALUES('','GAP','HG','1','11:00:00',0.00, '','','')
INSERT INTO GAP060 (empresa, aplicacao, tipo_param, cod_param, descricao, perc_abat, deb_cred, geral, cod_integ) VALUES('','GAP','df','HG','HR LIMITE EXE GAP815 1 8  N NASNN',0.00, '','','')

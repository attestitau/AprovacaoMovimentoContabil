﻿/// <reference path="IntelliSense.js" />

function MessageBoxInit() {
    return MessageBox;
}

//COLOCA IMAGEM E TITULO NA MENSAGEM E DIVISAO DO CORPO.
function Estruturar(img, titulo, mensagem) {
    return "<fieldset><legend><img src='" + img + "' width='29px' height='29px'/> " + titulo + "</legend><p>" + mensagem + "</p></fieldset>";
}

function DoNothing() { }

var MessageBox = {

    ShowRedirectMessage: function (mensagem, url) {
        /// <summary>Exibe mensagem e redireciona para Url uma definida</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="url" type="string">Url que será redirecionada apos a exibição da mensagem</param>

        var title = "Redirecionar?";

        img = Attest.Server().PathName() + "imagens/MessageBox/Question.PNG";

        var options = { message: Estruturar(img, title, mensagem) };

        bootbox.confirm(options.message, "Não", "Sim", function (result) {
            if (result && url != null)
                $(window.document.location).attr('href', url);
        });
    },
    ShowMessageError: function (mensagem, title) {
        /// <summary>Exibe mensagem de erro</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="title" type="string">Titulo da mensagem que será exibida. Valor padrão (Error!)</param>

        if (title == null)
            title = "Erro!";

        img = Attest.Server().PathName() + "Imagens/MessageBox/erro.gif";
        var options = { message: Estruturar(img, title, mensagem) };
        bootbox.dialog(options.message, [{
            "label": "OK",
            "class": "btn btn-danger"
        }]);
    },
    ShowMessageWarning: function (mensagem, title) {
        /// <summary>Exibe mensagem de Aviso</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="title" type="string">Titulo da mensagem que será exibida. Valor padrão (Aviso!)</param>

        if (title == null)
            title = "Aviso!";

        img = Attest.Server().PathName() + "imagens/MessageBox/alerta.png";
        var options = { message: Estruturar(img, title, mensagem) };
        bootbox.dialog(options.message, [{
            "label": "OK",
            "class": "btn btn-warning"
        }]);
    },
    ShowMessageAndRedirect: function (mensagem, url) {
        /// <summary>Exibe mensagem e redireciona para Url uma definida</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="url" type="string">Url que será redirecionada apos a exibição da mensagem</param>

        var title = "Informação!";
        img = Attest.Server().PathName() + "imagens/MessageBox/INFORMATION.gif";
        var options = { message: Estruturar(img, title, mensagem) };

        bootbox.alert(options.message, function () {
            $(window.document.location).attr('href', Attest.Server().PathName() + url);
        });
    },
    ShowMessage: function (mensagem, title) {
        /// <summary>Exibe mensagem</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="title" type="string">Titulo da mensagem que será exibida. Valor padrão (Informação!)</param>

        if (title == null) title = "Informação!";
        img = Attest.Server().PathName() + "Imagens/MessageBox/INFORMATION.gif";
        var options = { message: Estruturar(img, title, mensagem) };
        bootbox.alert(options.message);
    },
    ShowConfirmMessage: function (mensagem, callBackSim, callBackNao) {
        /// <summary>Exibe mensagem de confirmação</summary>
        /// <param name="mensagem" type="string">Mensagem que será exibida</param>
        /// <param name="callBackSim" type="function">Função que será executada se o botão sim for acionado</param>
        /// <param name="callBackNao" type="function">Função que será executada se o botão não for acionado</param>

        var title = "Confirma?";
        img = Attest.Server().PathName() + "Imagens/MessageBox/Question.PNG";

        if (callBackSim == null)
            callBackSim = DoNothing;

        if (callBackNao == null)
            callBackNao = DoNothing;

        var options = { message: Estruturar(img, title, mensagem) };

        bootbox.confirm(options.message, "Sim", "Não", function (result) {
            if (result && callBackNao() != null)
                callBackNao();
            else if (result == false && callBackSim != null)
                callBackSim();
        });
    },
    ShowGoBackMessage: function (mensagem) {

        titulo = "Voltar!";
        img = Attest.Server().PathName() + "Imagens/MessageBox/INFORMATION.gif";
        var options = { message: Estruturar(img, titulo, mensagem) };
        bootbox.confirm(options.message, "Não", "Sim", function (result) {
            if (result)
                history.back();
        });
    }
};
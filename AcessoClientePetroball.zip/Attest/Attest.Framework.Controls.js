﻿/// <reference path="IntelliSense.js" />

function ControlsInit() {
    return Controls;
}

var Controls = {
    FillListBox: function (idSourceValue, idListBox, allowDuplicate) {
        /// <summary>Preenche um listbox (html) com o valor de um determinado controle. O valor é passado após pressionar o "Enter".</summary>
        /// <param name="idSourceValue" type="string">Id do controle que irá fornecer o valor</param>
        /// <param name="idListBox" type="string">Id do listbox que irá receber o valor na lista</param>   
        /// <param name="allowDuplicate" type="boolean">Permite ou não incluir registros duplicados no listbox. Padrão: false</param>  
        if (allowDuplicate == null)
            allowDuplicate = false;
        $("#" + idSourceValue).keydown(function (e) {
            if (e.which == 13 || e.keyCode == 13) {
                if ($(this).val() != "") {
                    addItems($(this).val());
                    clearSourceValue();
                }
                return false;
            }
            return true;
        });

        function addItems(text) {
            var i = 0;
            if (!allowDuplicate) {
                $("#lstItems option").each(function () {
                    if (this.value == text)
                        i++;
                });
            }
            if (i == 0) {
                var option = '<option>' + text + '</option>';
                $("#" + idListBox).append(option);
            }
        }

        function clearSourceValue() {
            if ($("#" + idSourceValue).is('[type=text]'))
                $("#" + idSourceValue).val('');
        }

        $("#" + idListBox).dblclick(function () {
            $('option:selected', this).remove();
        });
    },
    Grid: {
        CreateColumnDetail: function (ColumnsIndex, fnCallBack) {
            /// <summary>Cria uma coluna de detalhes no Grid, possuindo um link para execução de um método personalizado, que recebe o valor das colunas definidas no ColumnsIndex como parâmetro.</summary>
            /// <param name="ColumnsIndex" type="string">Índice das colunas separadas por vírgula. Ex:"4,9"</param>
            /// <param name="fnCallBack" type="string">Nome da função a ser executada no click do detalhe Ex: "ReceberValores"</param>
            var Indexes = ColumnsIndex.toString().split(',');
            $('.table-bordered tr').each(function (i) {
                var td = '';
                if ($(this).children().is('th'))
                    td = '<td style="font-weight: bold;">Detalhes</td>';
                else {
                    var params = "";

                    for (j = 0; j < Indexes.length; j++) {
                        params += "'" + $(this).find('td').eq(Indexes[j]).text() + "',";
                    }
                    params = params.substring(0, params.length - 1);
                    td = '<td><a href="#" onclick="' + fnCallBack + '(' + params + ')">Detalhes</a></td>';
                }
                $(this).append(td);
            });
        },
        GetColumnText: function (RowIndex, ColumnsIndex) {
            /// <summary>Retorna o valor de uma ou mais colunas separadas por pipe (|) baseado no índice da linha do Grid (Considerando que <th></th> é o índice zero (0)) e nos índices das colunas.</summary>
            /// <param name="RowIndex" type="string"></param>
            /// <param name="ColumnsIndex" type="string">Índice das colunas separadas por vírgula. Ex:"4,9"</param>
            /// <returns type="String" />
            var Indexes = ColumnsIndex.toString().split(',');
            var Result = "";
            $('.table-bordered tr').each(function (i) {
                if (RowIndex == i) {
                    if ($(this).children().not('th')) {
                        for (j = 0; j < Indexes.length; j++) {
                            Result += $(this).find('td').eq(Indexes[j]).text() + "|";
                        }
                    }
                }
            });
            Result = Result.substring(0, Result.length - 1);
            return Result;
        }
    }
};
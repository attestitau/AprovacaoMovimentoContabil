﻿/// <reference path="IntelliSense.js" />

function UtilsInit() {
    return Utils;
}

var Utils = {
    DisableElements: function (id, elements) {
        /// <summary>Desabilita os controles de um determinado ID</summary>
        /// <param name="id" type="String">ID do container</param>
        /// <param name="elements" type="String">Elementos separados por virgula (input, select, textarea...)</param>
        $('#' + id).find(elements).attr('disabled', 'disabled');
    },
    ShowHideButtons: function (idButtons, showHide) {
        /// <summary>Exibe ou não os botões do AttestFramework</summary>
        /// <param name="IDButtons" type="String">Formato string separada por vírgulas</param>
        /// <param name="ShowHide" type="String">Formato string. Show | show | Hide | hide</param>
        var arrIDButtons = idButtons.split(',');

        for (var i = 0; i < arrIDButtons.length; i++) {
            if (document.getElementById(arrIDButtons[i].toString().trim()) != null) {
                if (showHide.toLowerCase() == 'show')
                    document.getElementById(arrIDButtons[i].toString().trim()).style.display = "";
                else
                    document.getElementById(arrIDButtons[i].toString().trim()).style.display = "none";
            }
        }
    },
    ShowHidePaginationNumber: function (showHide) {
        /// <summary>Exibe ou não os botões do número de registros por página</summary>
        /// <param name="ShowHide" type="String">Formato string. Show | show | Hide | hide</param>
        if (showHide.toLowerCase() == 'show')
            $('.btn.btn-small.dropdown-toggle').show();
        else
            $('.btn.btn-small.dropdown-toggle').hide();
    },
    DisableGridLink: function (application) {
        /// <summary>Desabilita o link do grid search</summary>
        /// <param name="application" type="String">Abreviatura do nome da aplicação. Ex: (CTB490, CTB210)</param>
        $('#grid' + application + ' a').attr('href', '#');
    },
    Time: function (format) {
        /// <summary>Exibe hora em 3 formatos</summary>
        /// <param name="format" type="String">'hh:mm:ss:ms', 'hh:mm:ss' ou 'hh:mm'</param>
        /// <returns type="String" />
        var now = new Date();
        var nowMiliseconds = now.getMilliseconds();
        var nowSeconds = now.getSeconds();
        var nowMinutes = now.getMinutes();
        var nowHours = now.getHours();
        var strNowMiliSeconds = nowMiliseconds < 10 ? "0" + nowMiliseconds : nowMiliseconds;
        var strNowSeconds = nowSeconds < 10 ? "0" + nowSeconds : nowSeconds;
        var strNowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
        var strNowHours = nowHours < 10 ? "0" + nowHours : nowHours;
        var strLongTime = strNowHours + ":" + strNowMinutes + ":" + strNowSeconds + ":" + strNowMiliSeconds;
        var strTime = strNowHours + ":" + strNowMinutes + ":" + strNowSeconds;
        var strShortTime = strNowHours + ":" + strNowMinutes;
        if (format == null)
            return strTime;
        else if (format == "hh:mm:ss:ms")
            return strLongTime;
        else if (format == "hh:mm:ss")
            return strTime;
        else if (format == "hh:mm")
            return strShortTime;
        else
            return "00:00";
    },
    Date: function (date) {
        /// <summary>Exibe data no formato dd/MM/yyyy</summary>
        /// <param name="date" type="String">Parâmetro opcional no formato dd/MM/yyyy</param>
        /// <returns type="String" />
        var now = new Date();
        if (date != null) {
            var dSplit = date.split('/');
            now = new Date(dSplit[1] + "/" + dSplit[0] + "/" + dSplit[2]);
        }
        var day = now.getDate();
        var month = now.getMonth() + 1; //Mês é baseado em Zero
        var year = now.getFullYear();
        var nowSeconds = now.getSeconds();
        var nowMinutes = now.getMinutes();
        var nowHours = now.getHours();
        var strDay = day < 10 ? "0" + day : day;
        var strMonth = month < 10 ? "0" + month : month;
        var strYear = year;
        var strDate = strDay + "/" + strMonth + "/" + strYear;
        return strDate;
    },
    DateTime: {
        Now: function () {
            /// <summary>Exibe data e hora no formato dd/MM/yyyy hh:mm:ss</summary>
            /// <returns type="String" />
            var now = new Date();
            var day = now.getDate();
            var month = now.getMonth() + 1; //Mês é baseado em Zero
            var year = now.getFullYear();
            var nowSeconds = now.getSeconds();
            var nowMinutes = now.getMinutes();
            var nowHours = now.getHours();
            var strDay = day < 10 ? "0" + day : day;
            var strMonth = month < 10 ? "0" + month : month;
            var strYear = year;
            var strNowSeconds = nowSeconds < 10 ? "0" + nowSeconds : nowSeconds;
            var strNowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
            var strNowHours = nowHours < 10 ? "0" + nowHours : nowHours;
            var strDate = strDay + "/" + strMonth + "/" + strYear + " " + strNowHours + ":" + strNowMinutes + ":" + strNowSeconds;
            return strDate;
        },
        AddYears: function (integer, date) {
            /// <summary>Exibe data e hora no formato dd/MM/yyyy</summary>
            /// <param name="date" type="String">Parâmetro opcional no formato dd/MM/yyyy</param>
            /// <param name="integer" type="String">Inteiro positivo ou negativo</param>
            /// <returns type="String" />
            if (integer == null)
                return '01/01/0001';
            var now = new Date();
            if (date != null) {
                var dSplit = date.split('/');
                now = new Date(dSplit[1] + "/" + dSplit[0] + "/" + dSplit[2]);
            }
            now.setFullYear(now.getFullYear() + parseInt(integer));
            var day = now.getDate();
            var month = now.getMonth() + 1; //Mês é baseado em Zero
            var year = now.getFullYear();
            var nowSeconds = now.getSeconds();
            var nowMinutes = now.getMinutes();
            var nowHours = now.getHours();
            var strDay = day < 10 ? "0" + day : day;
            var strMonth = month < 10 ? "0" + month : month;
            var strYear = year;
            var strDate = strDay + "/" + strMonth + "/" + strYear;
            return strDate;
        },
        AddMonths: function (integer, date) {
            /// <summary>Exibe data e hora no formato dd/MM/yyyy</summary>
            /// <param name="date" type="String">Parâmetro opcional no formato dd/MM/yyyy</param>
            /// <param name="integer" type="String">Inteiro positivo ou negativo</param>
            /// <returns type="String" />
            if (integer == null)
                return '01/01/0001';
            var now = new Date();
            if (date != null) {
                var dSplit = date.split('/');
                now = new Date(dSplit[1] + "/" + dSplit[0] + "/" + dSplit[2]);
            }
            now.setMonth(now.getMonth() + parseInt(integer));
            var day = now.getDate();
            var month = now.getMonth() + 1; //Mês é baseado em Zero
            var year = now.getFullYear();
            var nowSeconds = now.getSeconds();
            var nowMinutes = now.getMinutes();
            var nowHours = now.getHours();
            var strDay = day < 10 ? "0" + day : day;
            var strMonth = month < 10 ? "0" + month : month;
            var strYear = year;
            var strDate = strDay + "/" + strMonth + "/" + strYear;
            return strDate;
        },
        AddDays: function (integer, date) {
            /// <summary>Exibe data e hora no formato dd/MM/yyyy</summary>
            /// <param name="date" type="String">Parâmetro opcional no formato dd/MM/yyyy</param>
            /// <param name="integer" type="String">Inteiro positivo ou negativo</param>
            /// <returns type="String" />
            if (integer == null)
                return '01/01/0001';
            var now = new Date();
            if (date != null) {
                var dSplit = date.split('/');
                now = new Date(dSplit[1] + "/" + dSplit[0] + "/" + dSplit[2]);
            }
            now.setDate(now.getDate() + parseInt(integer));
            var day = now.getDate();
            var month = now.getMonth() + 1; //Mês é baseado em Zero
            var year = now.getFullYear();
            var nowSeconds = now.getSeconds();
            var nowMinutes = now.getMinutes();
            var nowHours = now.getHours();
            var strDay = day < 10 ? "0" + day : day;
            var strMonth = month < 10 ? "0" + month : month;
            var strYear = year;
            var strDate = strDay + "/" + strMonth + "/" + strYear;
            return strDate;
        },
        DayOfWeek: function (date) {
            /// <summary>Retorna o dia da semana em função da data</summary>
            /// <param name="date" type="String">Data no formato dd/MM/yyyy</param>
            /// <returns type="String" />
            var now = new Date();
            if (date != null) {
                var dSplit = date.split('/');
                now = new Date(dSplit[1] + "/" + dSplit[0] + "/" + dSplit[2]);
            }
            var dayOfWeek = now.getDay() + 1;
            switch (dayOfWeek) {
                default:
                    return 'undefined';
                case 1:
                    return 'Domingo';
                case 2:
                    return 'Segunda-feira';
                case 3:
                    return 'Terça-feira';
                case 4:
                    return 'Quarta-feira';
                case 5:
                    return 'Quinta-feira';
                case 6:
                    return 'Sexta-feira';
                case 7:
                    return 'Sábado';
            }
        }
    },
    TableToExcel: function (tableID) {
        /// <summary>Exportar tabela HTML para formato excel</summary>
        /// <param name="id" type="String">ID da tabela a ser exportada</param>
        if (Attest.Server().Browser.IE()) {

            var detailsTable = document.getElementById(tableID);

            var oExcel = new ActiveXObject("Excel.Application");
            var oBook = oExcel.Workbooks.Add;
            var oSheet = oBook.Worksheets(1);
            for (var y = 0; y < detailsTable.rows.length; y++) {
                for (var x = 0; x < detailsTable.rows(y).cells.length; x++) {
                    oSheet.Cells(y + 1, x + 1) = detailsTable.rows(y).cells(x).innerText;
                }
            }
            oExcel.Visible = true;
            oExcel.UserControl = true;
        }
        else if (Attest.Server().Browser.Chrome() || Attest.Server().Browser.Firefox()) {

            var div = $("#div_" + tableID);

            if (div == null) {
                $("#" + tableID).after('<div id="div_' + tableID + '" ></div>')
                var tb = $("#" + tableID).remove();
                tableID = "div_" + tableID;
                $("#" + tableID).append(tb);
            }

            var data = $("#" + tableID).html();
            data = escape(data);

            if (data.toLowerCase().indexOf("tbody")) {
                data = data.replace("tbody", "table").replace("/tbody", "/table");
                data = data.replace("<thead>", "").replace("</thead>", "");
            }

            window.open('data:application/vnd.ms-excel,' + data);
        }
        else
            Attest.MessageBox().ShowMessageWarning("Browser não suporta exportação para excel");
    },
    CountDownTimer: {
        targetID: "",
        type: "",
        tempoPrevisto: "",
        isPaused: false,
        isStopped: false,
        result: "",
        hasAction: false,
        actionStartAt: "",
        actionExpected: null,
        interval: null,
        Start: function () {
            /// <summary>Inicia o cronometro regressivo</summary>
            if (Attest.Utils().CountDownTimer.isPaused == false && Attest.Utils().CountDownTimer.isStopped == false) {
                Attest.Utils().CountDownTimer.isStopped = true;
            }
            var hours = 0;
            var minutes = 0;
            var seconds = 0;
            var strHours = "";
            var strMinutes = "";
            var strSeconds = "";
            var relogio = [];

            var vType = this.type;
            var vTargetID = this.targetID;

            if (Attest.Utils().CountDownTimer.isPaused) {
                clearInterval(Attest.Utils().CountDownTimer.interval);
                relogio = Attest.Utils().CountDownTimer.result.split(':');
                Attest.Utils().CountDownTimer.isPaused = false;
            }
            else if (Attest.Utils().CountDownTimer.isStopped) {
                clearInterval(Attest.Utils().CountDownTimer.interval);
                relogio = this.tempoPrevisto.split(':');
                Attest.Utils().CountDownTimer.isStopped = false;
            }
            else {
                relogio = this.tempoPrevisto.split(':');
            }

            function PassarValores() {
                if (relogio.length > 2) {
                    hours = parseInt(relogio[0]);
                    minutes = parseInt(relogio[1]);
                    seconds = parseInt(relogio[2]);
                }
                else {
                    hours = 0;
                    minutes = parseInt(relogio[1]);
                    seconds = parseInt(relogio[2]);
                }
            }

            function ResultCountDownTimer() {
                if (seconds > 0) {
                    seconds--;
                }
                else if (seconds == 0 && minutes > 0) {
                    seconds = 59;
                    minutes--;
                }
                else if (minutes == 0 && hours > 0) {
                    seconds = 59;
                    minutes = 59;
                    hours--;
                }

                strHours = hours < 10 ? "0" + hours : hours;
                strMinutes = minutes < 10 ? "0" + minutes : minutes;
                strSeconds = seconds < 10 ? "0" + seconds : seconds;

                Attest.Utils().CountDownTimer.result = strHours + ":" + strMinutes + ":" + strSeconds;

                //if (document.getElementById(idTarget) != null) {
                if (vType == "html")
                    $("#" + vTargetID).text(Attest.Utils().CountDownTimer.result);
                if (vType == "control")
                    $("#" + vTargetID).val(resultAttest.Utils().CountDownTimer.result);
                if (vType == "alert")
                    alert(Attest.Utils().CountDownTimer.result);
                //}

                DoWhenTimeIsReached(Attest.Utils().CountDownTimer.actionExpected);

                if (Attest.Utils().CountDownTimer.isPaused || Attest.Utils().CountDownTimer.isStopped)
                    clearInterval(Attest.Utils().CountDownTimer.interval);
            }

            function Start() {
                PassarValores();
                if (Attest.Utils().CountDownTimer.interval != null)
                    clearInterval(Attest.Utils().CountDownTimer.interval);
                Attest.Utils().CountDownTimer.interval = setInterval(ResultCountDownTimer, 1000);
            }

            function DoWhenTimeIsReached(func) {
                if (func != null && Attest.Utils().CountDownTimer.result == Attest.Utils().CountDownTimer.actionStartAt)
                    func();
            }

            Start();
        },
        Stop: function () {
            /// <summary>Pára o cronometro regressivo</summary>
            Attest.Utils().CountDownTimer.isStopped = true;
        },
        Pause: function () {
            /// <summary>Pausa o cronometro regressivo.</summary>
            Attest.Utils().CountDownTimer.isPaused = true;
        }
    },
    ProgressiveTimer: {
        targetID: "",
        type: "",
        tempoPrevisto: "",
        isPaused: false,
        isStopped: false,
        result: "",
        hasAction: false,
        actionStartAt: "",
        actionExpected: null,
        interval: null,
        Start: function () {
            /// <summary>Inicia o cronometro progressivo</summary>
            if (Attest.Utils().ProgressiveTimer.isPaused == false && Attest.Utils().ProgressiveTimer.isStopped == false) {
                Attest.Utils().ProgressiveTimer.isStopped = true;
            }
            var hours = 0;
            var minutes = 0;
            var seconds = 0;
            var strHours = "";
            var strMinutes = "";
            var strSeconds = "";
            var relogio = [];

            var vType = this.type;
            var vTargetID = this.targetID;

            if (Attest.Utils().ProgressiveTimer.isPaused) {
                clearInterval(Attest.Utils().ProgressiveTimer.interval);
                relogio = Attest.Utils().ProgressiveTimer.result.split(':');
                Attest.Utils().ProgressiveTimer.isPaused = false;
            }
            else if (Attest.Utils().ProgressiveTimer.isStopped) {
                clearInterval(Attest.Utils().ProgressiveTimer.interval);
                relogio = this.tempoPrevisto.split(':');
                Attest.Utils().ProgressiveTimer.isStopped = false;
            }
            else {
                relogio = this.tempoPrevisto.split(':');
            }

            function PassarValores() {
                if (relogio.length > 2) {
                    hours = parseInt(relogio[0]);
                    minutes = parseInt(relogio[1]);
                    seconds = parseInt(relogio[2]);
                }
                else {
                    hours = 0;
                    minutes = parseInt(relogio[1]);
                    seconds = parseInt(relogio[2]);
                }
            }

            function ResultProgressiveTimer() {
                if (seconds < 59) {
                    seconds++;
                }
                else if (seconds == 59 && minutes < 59) {
                    seconds = 00;
                    minutes++;
                }
                else if (minutes == 59 && hours < 59) {
                    seconds = 00;
                    minutes = 00;
                    hours++;
                }

                strHours = hours < 10 ? "0" + hours : hours;
                strMinutes = minutes < 10 ? "0" + minutes : minutes;
                strSeconds = seconds < 10 ? "0" + seconds : seconds;

                Attest.Utils().ProgressiveTimer.result = strHours + ":" + strMinutes + ":" + strSeconds;

                //if (document.getElementById(idTarget) != null) {
                if (vType == "html")
                    $("#" + vTargetID).text(Attest.Utils().ProgressiveTimer.result);
                if (vType == "control")
                    $("#" + vTargetID).val(resultAttest.Utils().ProgressiveTimer.result);
                if (vType == "alert")
                    alert(Attest.Utils().ProgressiveTimer.result);
                //}

                DoWhenTimeIsReached(Attest.Utils().ProgressiveTimer.actionExpected);

                if (Attest.Utils().ProgressiveTimer.isPaused || Attest.Utils().ProgressiveTimer.isStopped)
                    clearInterval(Attest.Utils().ProgressiveTimer.interval);
            }

            function Start() {
                PassarValores();
                if (Attest.Utils().ProgressiveTimer.interval != null)
                    clearInterval(Attest.Utils().ProgressiveTimer.interval);
                Attest.Utils().ProgressiveTimer.interval = setInterval(ResultProgressiveTimer, 1000);
            }

            function DoWhenTimeIsReached(func) {
                if (Attest.Utils().ProgressiveTimer.result == Attest.Utils().ProgressiveTimer.actionStartAt)
                    func();
            }

            Start();
        },
        Stop: function () {
            /// <summary>Pára o cronometro progressivo</summary>
            Attest.Utils().ProgressiveTimer.isStopped = true;
        },
        Pause: function () {
            /// <summary>Pausa o cronometro progressivo</summary>
            Attest.Utils().ProgressiveTimer.isPaused = true;
        }
    },
    Clock: {
        targetID: "",
        type: "",
        Init: function () {
            /// <summary>Exibe hora no formato hh:mm:ss</summary>
            /// <returns type="String" />
            var interval = null;
            var vType = this.type;
            var vTargetID = this.targetID;

            function GetTime() {
                var now = new Date();
                var nowSeconds = now.getSeconds();
                var nowMinutes = now.getMinutes();
                var nowHours = now.getHours();
                var strNowSeconds = nowSeconds < 10 ? "0" + nowSeconds : nowSeconds;
                var strNowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
                var strNowHours = nowHours < 10 ? "0" + nowHours : nowHours;
                var strClock = strNowHours + ":" + strNowMinutes + ":" + strNowSeconds;

                if (vType == "html")
                    $("#" + vTargetID).text(strClock);
                if (vType == "control")
                    $("#" + vTargetID).val(strClock);
                if (vType == "alert")
                    alert(strClock);
            }

            function Start() {
                if (interval != null)
                    clearInterval(interval);
                interval = setInterval(GetTime, 1000);
            }

            Start();
        }
    },
    Random: function (startInt, endInt) {
        return Math.floor(Math.random() * parseInt(endInt) + parseInt(startInt));
    }
}
﻿/// <reference path="IntelliSense.js" />

function ServerInit() {
    return Server;
}

var Server = {
    PathName: function (isSession) {
        var p = window.location.pathname.substring(0, 1);
        if (isSession == null)
            return p;
        else
            return p.toString().substring(0, p.indexOf("/(") + 1);
    },
    PageName: function () {

        var namePage = window.location.pathname.substring(0, 1);

        if (namePage.indexOf("?") > 0)
            namePage = namePage.substring(0, namePage.indexOf("?"));

        return namePage;
    },
    FullPath: function () {
        return Server.PathName() + Server.PageName();
    },
    GetUrlExecAjax: function (methodName) {
        return Server.PathName() + "Ajax/Exec.aspx/" + methodName;
    },
    GetUrlAjax: function (methodName) {
        return Server.PathName() + Server.PageName() + "/" + methodName;
    },
    ExistsUrlValue: function (value) {
        /// <summary>Verificar a existencia do valor na Url</summary>
        /// <param name="value" type="string">Valor a ser verificado se existe na Url</param>
        /// <returns type="Boolean">retorna um valor booleano</returns>
        return window.location.toString().toLowerCase().indexOf(value) != -1;
    },
    Redirect: function (url) {
        /// <summary>Redireciona para nova Url</summary>
        /// <param name="url" type="string">Url que será redirecionada</param>
        window.location = window.location.toString().substring(0, (window.location.toString().indexOf(window.location.pathname.split('/')[window.location.pathname.split('/').length - 1]) - 1)) + url;
    },
    Browser: {
        IE: function () {
            /// <summary>Verifica se o browser utilizado é Internet Explorer</summary>
            return /msie/.test(navigator.userAgent.toLowerCase()) || !!window.MSStream;
        },
        Chrome: function () {
            /// <summary>Verifica se o browser utilizado é Chrome</summary>
            return /chrome/.test(navigator.userAgent.toLowerCase());
        },
        Safari: function () {
            /// <summary>Verifica se o browser utilizado é Safari</summary>
            return navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0;
        },
        Firefox: function () {
            /// <summary>Verifica se o browser utilizado é Firefox</summary>
            return /firefox/.test(navigator.userAgent.toLowerCase());
        },
        Opera: function () {
            /// <summary>Verifica se o browser utilizado é Opera</summary>
            return /opera/.test(navigator.userAgent.toLowerCase());
        },
        Version: function () {
            /// <summary>Verifica a versão do browser utilizado</summary>

            var nVer = navigator.appVersion;
            var nAgt = navigator.userAgent;
            var browserName = navigator.appName;
            var fullVersion = '' + parseFloat(navigator.appVersion);
            var majorVersion = parseInt(navigator.appVersion, 10);
            var nameOffset, verOffset, ix;

            // In Opera, the true version is after "Opera" or after "Version"
            if ((verOffset = nAgt.indexOf("Opera")) != -1) {
                browserName = "Opera";
                fullVersion = nAgt.substring(verOffset + 6);
                if ((verOffset = nAgt.indexOf("Version")) != -1)
                    fullVersion = nAgt.substring(verOffset + 8);
            }
                // In MSIE, the true version is after "MSIE" in userAgent
            else if ((verOffset = nAgt.indexOf("MSIE")) != -1 || !!window.MSStream) {
                browserName = "Microsoft Internet Explorer";
                if (!!window.MSStream) fullVersion = "11"; else fullVersion = nAgt.substring(verOffset + 5);
            }
                // In Chrome, the true version is after "Chrome" 
            else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
                browserName = "Google Chrome";
                fullVersion = nAgt.substring(verOffset + 7);
            }
                // In Safari, the true version is after "Safari" or after "Version" 
            else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
                browserName = "Safari";
                fullVersion = nAgt.substring(verOffset + 7);
                if ((verOffset = nAgt.indexOf("Version")) != -1)
                    fullVersion = nAgt.substring(verOffset + 8);
            }
                // In Firefox, the true version is after "Firefox" 
            else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
                browserName = "Mozilla Firefox";
                fullVersion = nAgt.substring(verOffset + 8);
            }
                // In most other browsers, "name/version" is at the end of userAgent 
            else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
                browserName = nAgt.substring(nameOffset, verOffset);
                fullVersion = nAgt.substring(verOffset + 1);
                if (browserName.toLowerCase() == browserName.toUpperCase()) {
                    browserName = navigator.appName;
                }
            }
            // trim the fullVersion string at semicolon/space if present
            if ((ix = fullVersion.indexOf(';')) != -1) fullVersion = fullVersion.substring(0, ix);
            if ((ix = fullVersion.indexOf(' ')) != -1) fullVersion = fullVersion.substring(0, ix);

            majorVersion = parseInt('' + fullVersion, 10);

            if (isNaN(majorVersion)) {
                fullVersion = '' + parseFloat(navigator.appVersion);
                majorVersion = parseInt(navigator.appVersion, 10);
            }

            return fullVersion;
        },
        Mobile: function () {
            return navigator.userAgent.match(/Android/i) ||
                   navigator.userAgent.match(/webOS/i) ||
                   navigator.userAgent.match(/iPhone/i) ||
                   navigator.userAgent.match(/iPad/i) ||
                   navigator.userAgent.match(/iPod/i) ||
                   navigator.userAgent.match(/BlackBerry/i) ||
                   navigator.userAgent.match(/Windows Phone/i);
        },
        Permitted: function (redirect) {
            /// <summary>Verifica se o browser utilizado pelo usuário é homologado para utilização</summary>
            /// <param name="value" type="string">Se true, redireciona para tela de tratamento de browser</param>

            var br = Attest.Server().Browser.IE() || Attest.Server().Browser.Chrome() || Attest.Server().Browser.Safari() || Attest.Server().Browser.Firefox();

            if (!br && redirect) {

                var tipoError = "";
                if (navigator.userAgent.match(/iPad/i) != null)
                    tipoError = "IPad";
                else if (/Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent))
                    tipoError = "Plataforma";
                else
                    tipoError = "Browser";

                window.location = window.location.toString().split("(S(")[0] + 'Publico/BrowserError.aspx?Error=' + tipoError
            }

            return br;
        },
        CheckSession: function (sessionID) {

            var se = sessionID;
            var showScreen = "|attXyKw2";

            if (window.name == "" || window.name.substring(0, 3) != "New") {
                window.name = "New" + se + showScreen;
                var location = window.location.toString();

                if (window.location.toString().indexOf(se) != -1) {
                    window.location = location.substring(0, location.toString().indexOf(se)) + Math.random().toString() + location.substring(location.toString().indexOf(se), location.length);
                }
            }
            else {
                if (window.name.indexOf("New") != -1) {

                    if (window.location.toString().indexOf("/app") == -1) {
                        var sa = window.name.split("New")[1];

                        if (sa != "")
                            Attest.Ajax().Exec("EndSessionID", "{sessionID:'" + sa + "'}", null, 1);
                    }
                }

                window.name = se;
            }

            if (window.name.indexOf(showScreen) != -1)
                $('body').hide();
            else
                $('body').show();

            Attest.Session().Clear();
        }
    },
    OperatingSystem: function () {

        var OSName = "Not detected";

        if (navigator.appVersion.indexOf("Win") != -1) OSName = "Windows";
        if (navigator.appVersion.indexOf("Mac") != -1) OSName = "MacOS";
        if (navigator.appVersion.indexOf("X11") != -1) OSName = "UNIX";
        if (navigator.appVersion.indexOf("Linux") != -1) OSName = "Linux";

        return OSName;
    },
    GetQueryString: function () {

        var qs = "";

        $.ajax({
            url: Server.FullPath() + "/GetQueryString",
            data: "{'query':'" + window.location.search + "'}",
            dataType: "json",
            type: "POST",
            async: false,
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                qs = data.d;
                return qs;
            }
        });

        return qs;
    },
    QueryString: function () {
        /// <summary>Retorna os valores de uma querystring (ex: QueryString()["MyParam"]</summary>
        /// <returns type="Object">retorna um objeto com os valores dos parâmetros da url</returns>
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for(var i = 0; i < hashes.length; i++)
        {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    },
    UrlAuthority: function () {
        /// <summary>Retorna o nome de host do sistema</summary>
        /// <returns type="String">Retorna a string do nome de host do sistema</returns>
        var http = location.protocol;
        var port = location.port;
        var slashes = http.concat("//");
        var host = slashes.concat(window.location.hostname);
        if (port != null)
            return host + ":" + port;
        else
            return host;
    }
};





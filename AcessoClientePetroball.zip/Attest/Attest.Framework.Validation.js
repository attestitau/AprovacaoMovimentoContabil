﻿/// <reference path="IntelliSense.js" />

function ValidationInit() {
    return Validation;
}

var Validation = {
    isNumber: function (event) {
        /// <summary>Permite somente entrada de dados numérico</summary>
        /// <param name="event">Sem formato</param>
        var code = (event.keyCode ? event.keyCode : event.which);
        var character = String.fromCharCode(code);
        var AllowRegex = /[0-9,]/;
        return (AllowRegex.test(character));
    },
    isText: function (event) {
        /// <summary>Permite somente entrada de dados alfanuméricos</summary>
        /// <param name="event">Sem formato</param>
        var code = (event.keyCode ? event.keyCode : event.which);
        var character = String.fromCharCode(code);
        var AllowRegex = /^[\ba-zA-Z\s-]$/;
        return (AllowRegex.test(character));
    },
    isVF: function (event) {
        /// <summary>Permite somente entrada de V ou F</summary>
        /// <param name="event">Sem formato</param>
        var code = (event.keyCode ? event.keyCode : event.which);
        var character = String.fromCharCode(code);
        var AllowRegex = /[vVfF]/;
        return (AllowRegex.test(character)); 
    },
    Email: function (value) {
        /// <summary>Valida e-mail</summary>
        /// <param name="value">E-mail a ser validado</param>
        /// <returns type="Boolean">retorna um valor booleano</returns>
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },
    Cpf: function (cpf) {
        /// <summary>Valida Cpf</summary>
        /// <param name="cpf">Cpf a ser validado</param>
        /// <returns type="Boolean">retorna um valor booleano</returns>

        cpf = String(cpf).replace(/\D/g, "").replace(/^0+/, "")

        var soma;
        var resto;
        var i;

        if ((cpf.length != 11) ||
        (cpf == "00000000000") || (cpf == "11111111111") ||
        (cpf == "22222222222") || (cpf == "33333333333") ||
        (cpf == "44444444444") || (cpf == "55555555555") ||
        (cpf == "66666666666") || (cpf == "77777777777") ||
        (cpf == "88888888888") || (cpf == "99999999999")) {
            return false;
        }

        soma = 0;

        for (i = 1; i <= 9; i++) {
            soma += Math.floor(cpf.charAt(i - 1)) * (11 - i);
        }

        resto = 11 - (soma - (Math.floor(soma / 11) * 11));

        if ((resto == 10) || (resto == 11)) {
            resto = 0;
        }

        if (resto != Math.floor(cpf.charAt(9))) {
            return false;
        }

        soma = 0;

        for (i = 1; i <= 10; i++) {
            soma += cpf.charAt(i - 1) * (12 - i);
        }

        resto = 11 - (soma - (Math.floor(soma / 11) * 11));

        if ((resto == 10) || (resto == 11)) {
            resto = 0;
        }

        if (resto != Math.floor(cpf.charAt(10))) {
            return false;
        }

        return true;
    },
    Cnpj: function (cnpj) {
        /// <summary>Valida Cnpj</summary>
        /// <param name="Cnpj">Cnpj a ser validado</param>
        /// <returns type="Boolean">retorna um valor booleano</returns>

        cnpj = String(cnpj).replace(/\D/g, "").replace(/^0+/, "")

        var i;
        var c = cnpj.substr(0, 12);
        var dv = cnpj.substr(12, 2);
        var d1 = 0;

        for (i = 0; i < 12; i++) {
            d1 += c.charAt(11 - i) * (2 + (i % 8));
        }

        if (d1 == 0) return false;

        d1 = 11 - (d1 % 11);

        if (d1 > 9) d1 = 0;
        if (dv.charAt(0) != d1) {
            return false;
        }

        d1 *= 2;

        for (i = 0; i < 12; i++) {
            d1 += c.charAt(11 - i) * (2 + ((i + 1) % 8));
        }

        d1 = 11 - (d1 % 11);

        if (d1 > 9) d1 = 0;
        if (dv.charAt(1) != d1) {
            return false;
        }

        return true;
    },
    CpfCnpj: function (valor) {
        /// <summary>Valida Cnpj ou Cnpj</summary>
        /// <param name="valor">Cnpj a ser validado</param>
        /// <returns type="Boolean">retorna um valor booleano</returns>

        var retorno = false;

        if (valor.length > 11) {
            retorno = Validation.Cnpj(valor)
        } else {
            retorno = Validation.Cpf(valor);
        }

        return retorno;
    },
    ConsistencyBeforeAction: function () {
        if (!BeforeAction())
            return false;

        if (z) {

            var collections = $("input,select,textarea").jqBootstrapValidation("collectErrors");

            var lstError = "";
            var fieldObj = "";

            $.each(collections, function (key, value) {

                try {

                    var element = $('input[name="' + key + '"]');

                    var label = element.attr("requiredmessage");

                    if (label != null) {
                        lstError += ' ' + label + '<br>';
                    }
                    else {

                        if (element.attr("autocomplete") != null)
                            label = $('label[for="' + element.attr("id") + '"]').text();
                        else
                            label = element.attr("textlabel");

                        if (label != null)
                            lstError += ' ' + label + " é de preenchimento obrigatório<br>";
                    }
                } catch (e) {

                }
            });

            Attest.MessageBox().ShowMessage(lstError, "Inconsistências");

            return false;
        }

        return true;
    }
};
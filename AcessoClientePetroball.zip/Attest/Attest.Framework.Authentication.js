﻿/// <reference path="../JScript/Attest.Web.UI.IntelliSense.js" />

function AuthenticationInit() {
    return Authentication;
}

var Authentication = {
    GetToken: function () {
        /// <summary>Retorna um token criptografado</summary>
        /// <returns type="String" />
        var t = null;
        Attest.Ajax().Exec("GetToken", null, function (data) {
            if (data.d.MensagemSistema != "Sucesso") {
                ShowMessage(data.d.MensagemSistema, "Inconsistências");
                return;
            }
            t = data.d.Token;
        }, 1, false);
        return t;
    }
};
﻿/// <reference path="IntelliSense.js" />

function ArrayInit() {
    return Array;
}

var Array = {
    Shuffle: function (array) {
        for (var j, x, i = array.length; i; j = parseInt(Math.random() * i), x = array[--i], array[i] = array[j], array[j] = x);
        return array;
    },
    Raffle: function (array, totalRaffle) {
        var rnd = Attest.Array.Shuffle(array);
        rnd.splice(totalRaffle, (array.length - totalRaffle));
        return rnd.sort();
    },
    RemoveByIndex: function (array, index) {
        array.splice(index, 1);
        return array;
    },
    RemoveByValue: function (array, value) {
        for (var i = 0; i < array.length; i++) {
            if (array[i] == value) {
                array.splice(i, 1);
                break;
            }
        }
        return array;
    },
    RemoveDuplicates: function (array) {
        var temp = {};
        for (var i = 0; i < array.length; i++)
            temp[array[i]] = true;

        var r = [];
        for (var k in temp)
            r.push(k);
        return r;
    }
};
﻿/// <reference path="IntelliSense.js" />

function ConvertInit() {
    return Convert;
}

var Convert = {
    ToSeconds: function (value) {
        /// <summary>Converte a hora em segundos</summary>
        /// <param name="value" type="String">Formato hh:mm:ss ou mm:ss</param>
        /// <returns type="Int" />
        if (value.indexOf(':') >= 0) {
            var time = value.split(':');
            var second = 0;
            if (time.length > 2)
                seconds = (parseInt(time[0]) * 3600) + (parseInt(time[1]) * 60) + parseInt(time[2]);
            else
                seconds = (parseInt(time[0]) * 60) + parseInt(time[1]);
        }
        else {
            var time = value;
            var second = 0;
            seconds = parseInt(time) * 60;
        }
        return seconds;
    },
    ToTimeSpan: function (secondsValue) {
        /// <summary>Converte a hora em segundos</summary>
        /// <param name="secondsValue" type="Int">Formato número inteiro</param>
        /// <returns type="String" />
        var hours = parseInt(secondsValue / 3600) % 24;
        var minutes = parseInt(secondsValue / 60) % 60;
        var seconds = secondsValue % 60;
        var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
        return result;
    },
    ToCurrency: function (value, c, d, t) {
        /// <summary>Converte um número em moeda</summary>
        /// <param name="value" type="Decimal">Formato numérico</param>
        /// <param name="c" type="Int">Número de casas decimais</param>
        /// <param name="d" type="String">Separador de casas decimais (ex:',')</param>
        /// <param name="t" type="String">Separador de casas de milhar (ex:'.')</param>
        /// <returns type="String" />
        var n = value,
                c = isNaN(c = Math.abs(c)) ? 2 : c,
                d = d == undefined ? "." : d,
                t = t == undefined ? "," : t,
                s = n < 0 ? "-" : "",
                i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
                j = (j = i.length) > 3 ? j % 3 : 0;
        return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
    }
};
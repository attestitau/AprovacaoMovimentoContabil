﻿/// <reference path="IntelliSense.js" />

function ExtensionInit() {

    try {

        if (!String.prototype.trim) {
            String.prototype.trim = function () { return this.replace(/^\s+|\s+$/g, ''); };
            String.prototype.ltrim = function () { return this.replace(/^\s+/, ''); };
            String.prototype.rtrim = function () { return this.replace(/\s+$/, ''); };
            String.prototype.fulltrim = function () { return this.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g, '').replace(/\s+/g, ' '); };
        }

        if (!String.prototype.contains) {
            String.prototype.contains = function (value) {
                /// <summary>Verificar a existencia do valor em uma string</summary>
                /// <param name="value" type="string">Valor a ser verificado se existe na string</param>
                return this.toString().toLowerCase().indexOf(value) != -1;
            };
        }

    } catch (e) {

    }
}


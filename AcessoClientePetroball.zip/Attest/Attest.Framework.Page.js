﻿/// <reference path="IntelliSense.js" />

function PageInit() {
    return Page;
}

var Page = {
    Map: function () {
        /// <summary>Faz o mapeamento dos controles da página para Objeto</summary>
        /// <returns type="Object">retorna object</returns>

        var obj = {};

        $('input,checked,select,button,textarea').each(function () {

            var obj = $(this);
            var name = obj.attr('id');

            if (obj.attr('data-map-name') != null)
                name = obj.attr('data-map-name');

            if (name != null)
                obj[name] = obj;
        });

        obj.Obj = function () {
            /// <summary>Faz o mapeamento dos controles da página para Objeto Json</summary>
            /// <returns type="Object">retorna object</returns>

            var result = {};

            for (var key in obj) {
                var value = objects[key];
                result[key] = value;
            }

            return JSON.stringify(result);
        }

        obj.Clear = function () {
            /// <summary>Limpa os controles da página</summary>
            for (var key in obj) {
                $('#' + key).val('');
            }
        }

        return obj;
    }
}
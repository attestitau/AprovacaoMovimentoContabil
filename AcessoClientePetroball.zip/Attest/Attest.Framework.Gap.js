﻿
function GapInit() {
    return Gap;
}

var Gap = {
    Erro: {
        Obter: function (codigo, modal) {
            /// <summary>Exibe o erro no console do Browser</summary>
            /// <param name="code" type="int">codigo erro</param>
            /// <returns type="Object" />
            Attest.Ajax().Exec("ObterErro", "{'codigo':" + codigo + "}", function (data) {
                if (modal) {
                    var li = '<li><b>Data:</b> ' + data.d.Obj.Data + '</li>' +
                             '<li><b>Descrição:</b> ' + data.d.Obj.Descricao + '</li>' +
                             '<li><b>Usuário:</b> ' + data.d.Obj.Usuario + '</li>' +
                             '<li><b>Linnha:</b> ' + data.d.Obj.Linha + '</li>' +
                             '<li><b>Erro:</b> ' + data.d.Obj.Erro + '</li>';

                    var msg = '<ul>' + li + '<ul>';

                    Attest.MessageBox().ShowMessageError(msg);
                }
                else
                    console.log(data.d.Obj);
            }, 1)
        },
        Salvar: function (erro) {
            /// <summary>Faz log de erro no GapErro</summary>
            /// <param name="erro" type="string">Erro a ser logado</param>
            /// <returns type="Object" />
            Attest.Ajax().Exec("LogErro", "{'erro':'" + erro + "'}", function () { }, 1)
        }
    }
}
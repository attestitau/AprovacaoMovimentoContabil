﻿/// <reference path="IntelliSense.js" />

function AjaxInit() {
    return Ajax;
}

var Ajax = {
    Exec: function (methodName, jsonParam, success, urlOptions, async, complete, error, dataType, type, contentType) {
        /// <summary>Execução Ajax</summary>
        /// <param name="methodName" type="string">Nome do método ou Url que que será executado</param>
        /// <param name="jsonParam" type="string">Parametros no formato json</param>
        /// <param name="success" type="function">Função a ser executada no sucesso do Ajax. Por padrão essa função recebe como argumento o data, retorno padrão da execução $.Ajax</param>
        /// <param name="urlOptions" type="int">Tipo de url a ser executada. (0 - Executa propria página, 1 - Executa pasta ajax, 2 - Executa url externa). Padrão 0 </param>
        /// <param name="async" type="boolean">Tipo da execução Ajax. Padão true</param>
        /// <param name="complete" type="function">Função a ser executada no complete sucesso do Ajax. Por padrão essa função recebe como argumento jqXHR e textStatus, retorno padrão da execução $.Ajax</param>
        /// <param name="error" type="function">Função a ser executada se ocorrer erro na execução Ajax. Por padrão essa função recebe como argumento jqXHR, textStatus e errorThrown, retorno padrão da execução $.Ajax</param>
        /// <param name="dataType" type="String">Tipo retorno da execução Ajax. Padrão 'json'</param>
        /// <param name="type" type="String">Tipo da execução ajax. Padrão 'POST'</param>
        /// <param name="contentType" type="String">Tipo do conteudo execução Ajax. Padrão 'application/json; charset=utf-8'</param>

        if (jsonParam == null)
            jsonParam = "{}";

        if (urlOptions == null)
            urlOptions = 0;

        if (dataType == null)
            dataType = "json";

        if (type == null)
            type = "POST";

        if (contentType == null)
            contentType = "application/json; charset=utf-8";

        if (async == null)
            async = true;

        var url = urlOptions == 0 ? Attest.Server().GetUrlAjax(methodName) : urlOptions == 1 ? Attest.Server().GetUrlExecAjax(methodName) : methodName;

        $.ajax({
            url: url,
            data: jsonParam,
            async: async,
            dataType: dataType,
            type: type,
            contentType: contentType,
            success: function (data) {

                if (typeof success != "function")
                    return;

                success(data);
            },
            complete: function (jqXHR, textStatus) {

                if (typeof complete != "function")
                    return;

                complete(jqXHR, textStatus);
            },
            error: function (jqXHR, textStatus, errorThrown) {

                if (typeof error != "function")
                    return;

                error(jqXHR, textStatus, errorThrown);
            }
        });
    },
    SetAjax: function () {
        /// <summary>Configuração global das execuções Ajax</summary>

        //Exibe mensagem em execuções Ajax
        $(document).ajaxStart(function () {
            $("#mainContent").prepend("<div id='load' class='alert alert-block' style='left:50%; right:50%;height:15px;width:80px; position: absolute;'><b>Processando... </b></div>");
        });

        //Oculta mensagem em execuções Ajax
        $(document).ajaxComplete(function () {
            $("#load").remove();
        });

        //Tratamento de error execuções ajax. Gravar na tabela gaperror
        $(document).ajaxError(function (event, request, options, error) {
            console.log(event); //Remover, somente teste
            console.log(request); //Remover, somente teste
            console.log(options); //Remover, somente teste
            console.log(error); //Remover, somente teste
        });
    }
}
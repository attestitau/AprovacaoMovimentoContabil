﻿/// <reference path="IntelliSense.js" />

function SessionInit() {

    var js = document.createElement("script");
    js.type = "text/javascript";
    js.src = window.location.pathname.toString().substring(0, window.location.pathname.toString().indexOf("))/") + 3) + "jQuery/js/jquery.session.js";
    $("head").append(js);

    return Session;
}

var Session = {
    SetControlToSession: function (ControlID) {
        $.session.set(ControlID, Attest.Crypt().EncodeBase64($("#" + ControlID).html()));
    },
    GetControFromSession: function (ControlID) {
        $("#" + ControlID).html(Attest.Crypt().DecodeBase64($.session.get(ControlID)));
    },
    GetIDByUrl: function () {
        /// <summary>Obtem o número da sessão baseado na Url</summary>
        /// <returns type="String" />
        var SessionUrl = "";
        if (window.location.toString().indexOf("/(S(") > 0) {
            SessionUrl = window.location.toString().substring(window.location.toString().indexOf("/(S("), window.location.toString().indexOf("))") + 2);
            SessionUrl = SessionUrl.replace("/(S(", "").replace("))", "")
        }
        return SessionUrl;
    },
    GetIDByWindowName: function () {
        /// <summary>Obtem o número da sessão baseado no window.name</summary>
        /// <returns type="String" />
        return window.name;
    },
    Get: function (name) {
        /// <summary>Obter um valor adicionado na sessão</summary>
        /// <param name="name" type="string">Nome do valor a obter na sessão</param>
        return $.session.get(name);
    },
    Set: function (name, value) {
        /// <summary>Incluir um valor na sessão</summary>
        /// <param name="name" type="string">Nome do valor a ser adicionado na sessão</param>
        /// <param name="value" type="string">Valor a ser adicionado na sessão</param>
        $.session.set(name, value);
    },
    Remove: function (name) {
        /// <summary>Remove um valor na sessão</summary>
        /// <param name="value" type="string">Nome do valor adicionado na sessão a ser removido</param>
        $.session.remove(name);
    },
    Clear: function () {
        /// <summary>Limpa a sessão do browser</summary>
        $.session.clear();
    },
    Validate: function () {
        /// <summary>Verifica se a sessão do browser corresponde a sessão corrente</summary>
        if (window.name == "" || window.name != this.GetIDByUrl()) {

            if (window.location.toString().toLowerCase().indexOf("&typeredirect=token")) {
                window.name = this.GetIDByUrl();
                return;
            }

            if (Attest.Server().ExistsUrlValue("/app/")) {
                window.location = window.location.toString().substring(0, window.location.toString().toLowerCase().indexOf("/app/")) + "/login.aspx?oldUrl=" + window.location.toString() + "&empresa=" + Attest.ClientContext.CodigoEmpresa + "&filial=" + Attest.ClientContext.CodigoFilial;
            }
            else {
                window.location = "login.aspx";
            }
        }
    },
    CheckTimeOut: function (redirectLogin) {
        /// <summary>Verifica se a sessão do usuário foi encerrada</summary>
        var result = false;
        Attest.Ajax().Exec("CheckTimeOutSession", null, function (data) {
            if (data.d.Result != "OK") {
                if (redirectLogin) {
                    Attest.MessageBox().ShowMessageAndRedirect("Sua sessão expirou, favor identificar-se novamente", "Login.aspx");
                }

                result = true;
            }
        }, 1, false);
    }
};
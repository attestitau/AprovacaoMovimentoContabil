﻿/// <reference path="IntelliSense.js" />

Init();

function RegisterFrameworkScript(name) {

    var file = "Attest/Attest.Framework." + name + ".js";

    if ($("head").toString().indexOf(file) < 0) {
        var js = document.createElement("script");
        js.type = "text/javascript";
        js.src = window.location.pathname.substring(0, 1) + file;
        js.id = "jsrt" + name;
        $("head").append(js);
    }
}

function Init() {
    OverridejQuery();
}

var InstanceAjax = null;
var InstanceServer = null;
var InstanceAuthentication = null;
var InstanceControls = null;
var InstanceCrypt = null;
var InstanceSession = null;
var InstanceUtils = null;
var InstanceArray = null;
var InstanceConvert = null;
var InstanceValidation = null;
var InstanceMessageBox = null;
var InstancePage = null;
var InstanceGap = null;

var Attest = {

    Authentication: function () {
        /// <summary>Função server</summary>
        if (InstanceAuthentication == null) {
            RegisterFrameworkScript("Authentication");
            InstanceAuthentication = AuthenticationInit();
        }
        return InstanceAuthentication;
    },
    Controls: function () {
        /// <summary>Funções para manipulação de controles</summary>
        if (InstanceControls == null) {
            RegisterFrameworkScript("Controls");
            InstanceControls = ControlsInit();
        }
        return InstanceControls;
    },
    Server: function () {
        /// <summary>Função server</summary>
        if (InstanceServer == null) {
            RegisterFrameworkScript("Server");
            InstanceServer = ServerInit();
        }
        return InstanceServer;
    },
    Crypt: function () {
        /// <summary>Função de criptografia</summary>
        if (InstanceCrypt == null) {
            RegisterFrameworkScript("Crypt");
            InstanceCrypt = CryptInit();
        }
        return InstanceCrypt;
    },
    Session: function () {
        /// <summary>Função de acesso a Sessão</summary>
        if (InstanceSession == null) {
            RegisterFrameworkScript("Session");
            InstanceSession = SessionInit();
        }
        return InstanceSession;
    },
    Ajax: function () {
        /// <summary>Função de execuções Ajax</summary>
        if (InstanceAjax == null) {
            RegisterFrameworkScript("Ajax");
            InstanceAjax = AjaxInit();
        }
        return InstanceAjax;
    },
    Utils: function () {
        /// <summary>Função utilitario</summary>
        if (InstanceUtils == null) {
            RegisterFrameworkScript("Utils");
            InstanceUtils = UtilsInit();
        }
        return InstanceUtils;
    },
    Array: function () {
        /// <summary>Função para manipulação de Array</summary>
        if (InstanceArray == null) {
            RegisterFrameworkScript("Array");
            InstanceArray = ArrayInit();
        }
        return InstanceArray;
    },
    Convert: function () {
        /// <summary>Função de Conversão</summary>
        if (InstanceConvert == null) {
            RegisterFrameworkScript("Convert");
            InstanceConvert = ConvertInit();
        }
        return InstanceConvert;
    },
    Validation: function () {
        /// <summary>Função de Validação</summary>
        if (InstanceValidation == null) {
            RegisterFrameworkScript("Validation");
            InstanceValidation = ValidationInit();
        }
        return InstanceValidation;
    },
    MessageBox: function () {
        /// <summary>Função com opções de Exibição de Mensagens</summary>
        if (InstanceMessageBox == null) {
            RegisterFrameworkScript("MessageBox");
            InstanceMessageBox = MessageBoxInit();
        }
        return InstanceMessageBox;
    },
    RegisterScript: function (filePath) {
        /// <summary>Função para adicionar referencia de arquivos</summary>
        /// <param name="filePath" type="string">Arquivo que será referenciado na pagina</param>
        var js = document.createElement("script");
        js.type = "text/javascript";
        js.src = filePath;
        $("head").append(js);
    },
    Page: function () {
        /// <summary>Função Page</summary>
        if (InstancePage == null) {
            RegisterFrameworkScript("Page");
            InstancePage = PageInit();
        }
        return InstancePage;
    },
    Gap: function () {
        /// <summary>Função server</summary>
        if (InstanceGap == null) {
            RegisterFrameworkScript("Gap");
            InstanceGap = GapInit();
        }
        return InstanceGap;
    },
    ClientContext: {
        /// <summary>Contexto da aplicação</summary>
        CodigoUsuario: "",
        NomeUsuario: "",
        CodigoEmpresa: "",
        NomeEmpresa: "",
        CodigoFilial: "",
        NomeFilial: "",
        Aplicacao: "",
        Modulo: "",
        Rotina: "",
        Ambiente: "",
        CodigoPrograma: ""
    }
}


function OverridejQuery() {

    $.fn.val = function (value) {
        /// <summary>Atribui ou Obtem valor do controle</summary>
        /// <param name="value" type="string">Valor atribuido no controle</param>

        if (typeof value != 'undefined' && value.toString().trim() == '' && this.attr('key') && this.attr('autocomplete')) {
            document.getElementById('hidden' + this.attr('id')).value = value;
            document.getElementById(this.attr('id')).value = value;
            this.removeAttr('key');
            this.removeAttr('tempvalue');
        }
        else if (typeof value != 'undefined') {
            document.getElementById(this.attr('id')).value = value;
        }
        else
            return document.getElementById(this.attr('id')) != null ? document.getElementById(this.attr('id')).value : "";
    };

    $.fn.enabled = function (enable, clear) {
        /// <summary>Ativa ou inativa controle</summary>
        /// <param name="enable" type="boolean">Inativar o controle</param>
        /// <param name="clear" type="boolean">Limpar valor do controle</param>

        if (clear)
            this.val('');

        if (enable)
            this.attr('disabled', 'disabled');
        else
            this.removeAttr('disabled');
    };
}

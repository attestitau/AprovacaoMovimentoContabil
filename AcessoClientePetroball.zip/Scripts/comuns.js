// Fun��o respons�vel por iniciar o Objeto XMLHttpRequest
function IniciaAjax(){
	var ajax;	// Varivel que se tornar� o objeto XMLHttpRequest
	if(window.XMLHttpRequest){	  // Mozilla, Safari,...
		ajax = new XMLHttpRequest();
	}else if(window.ActiveXObject){	// IE
		ajax = new ActiveXObject("Msxml2.XMLHTTP");
		if (!ajax) {
			ajax = new ActiveXObject("Microsoft.XMLHTTP");
		}
    }else{
        alert("Seu navegador n�o possui suporte a essa aplica��o!");
	}
	return ajax;
}

// Fun��o respons�vel por carregar uma p�gina dentro de uma determinada DIV
// Recebemos 2 valores sendo:
// url=> Informa a p�gina que ser� processada
// div=> Informo o ID da DIV em que deveremos trabalhar.
// Utilizo o carregando generico
function ExibePagina(url,div){
	ajax = IniciaAjax();
	if(ajax){
		ajax.onreadystatechange = function(){
			if (ajax.readyState == 1 ){		// Estado ainda n�o completado (carregando)
				document.getElementById(div).innerHTML="<img src=\"images\/ajax-loader.gif\" width=\"16\" height=\"16\" \/> Carregando...";
			}
			if(ajax.readyState == 4) {
				if(ajax.status == 200) {
					document.getElementById(div).innerHTML = ajax.responseText;
				} else {
					alert(ajax.statusText);
				}
			}
		}
			url = url;
			ajax.open('GET',url, true);
			ajax.send(null);
	}
}

function LogOut() {
    if (confirm('Deseja desconectar do Acesso do Cliente?'))
        window.location = '../CommonPages/LogOut.ashx';
}